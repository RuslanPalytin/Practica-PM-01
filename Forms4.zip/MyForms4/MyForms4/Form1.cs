﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyForms4
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox7.Text = "";
            double x0 = Convert.ToDouble(textBox1.Text);
            double xk = Convert.ToDouble(textBox2.Text);
            double dx = Convert.ToDouble(textBox3.Text);
            double a = Convert.ToDouble(textBox4.Text);
            double b = Convert.ToDouble(textBox5.Text);
            double c = Convert.ToDouble(textBox6.Text);
            if (a < 0)
                textBox7.Text += "ПРЕДУПРЕЖДЕНИЕ" + Environment.NewLine + "Невозможно извлечь корень из отрицательного числа (при x > 0)! " + Environment.NewLine;
            else
                textBox7.Text += "ПРЕДУПРЕЖДЕНИЕ" + Environment.NewLine + "Невозможно извлечь корень из отрицательного числа (при x < 0)! " + Environment.NewLine;
            double x = x0;
            while (x <= (xk + dx / 2))
            {
                double y = 0.01 * b * c / x + Math.Cos(Math.Sqrt(a * a * a * x));
                textBox7.Text += "x = " + Convert.ToString(x) + " ; y = " + Convert.ToString(y) + Environment.NewLine;
                x += dx;
            }
        }
    }
}
